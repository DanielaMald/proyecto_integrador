<?php
include ("../../controller/administrador/borrar_alumno.php");
?>