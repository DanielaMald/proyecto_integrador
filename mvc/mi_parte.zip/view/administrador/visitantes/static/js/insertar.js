function insertar() {
    var nombres = document.getElementById('nombres').value;
    var ap_paterno = document.getElementById('apellido_paterno').value;
    var ap_materno = document.getElementById('apellido_materno').value;
    var motivo = document.getElementById('motivo').value;
    var dispositivo = document.getElementById('dispositivo').value;
    

    var request = new XMLHttpRequest();
    request.open('POST', "http://127.0.0.1:3900/api/crear");
    request.setRequestHeader("Content-Type", "application/json");

    request.onload = function () {
        if (request.status === 200) {
            const response = JSON.parse(request.responseText);
            console.log("Respuesta:", response);
            alert("vistante insertado correctamente");
            window.location.href = "https://localhost/efi1002/mvc/view/administrador/admin.html";
        } else {
            console.error("Error al hacer la solicitud:", request.status, request.statusText);
            alert("Error al insertar el contacto. Por favor, inténtalo de nuevo.");
        }
    };

    request.onerror = function () {
        console.error("Error de red al intentar hacer la solicitud.");
        alert("Error de red al intentar insertar el contacto. Por favor, inténtalo de nuevo.");
    };

    var data = {
        nombres: nombres,
        apellido_paterno: ap_paterno,
        apellido_materno: ap_materno,
        motivo: motivo,
        dispositivo: dispositivo
    };

    request.send(JSON.stringify(data));
}

function cancelar() {
    window.location.href = "https://localhost/efi1002/mvc/view/administrador/admin.html";
    alert("Acción cancelada");
}
