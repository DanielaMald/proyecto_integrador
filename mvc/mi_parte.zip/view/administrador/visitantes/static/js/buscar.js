function buscarporEmail() {
    const emailInput = document.getElementById("buscarEmail").value;
    const token = sessionStorage.getItem("token");

    if (!token) {
        console.error('Token no encontrado en sessionStorage.');
        return;
    }

    fetch(`http://127.0.0.1:8000/contactos/${emailInput}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    })
    .then(response => response.json())
    .then(data => {
        const resultTable = document.getElementById("buscarResult");
        resultTable.innerHTML = "";

        if (data) {
            const row = resultTable.insertRow(0);

            const emailCell = row.insertCell(0);
            const nombreCell = row.insertCell(1);
            const telefonoCell = row.insertCell(2);

            emailCell.innerHTML = data.email;
            nombreCell.innerHTML = data.nombre;
            telefonoCell.innerHTML = data.telefono;
        } else {
            const errorMessage = document.createElement("p");
            errorMessage.innerHTML = "Contacto no encontrado.";
            resultTable.appendChild(errorMessage);
        }
    })
    .catch(error => {
        console.error('Error en la solicitud:', error);
    });
}
