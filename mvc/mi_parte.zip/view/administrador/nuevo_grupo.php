<?php
require "../../controller/administrador/nuevo_grupo.php";
?>
